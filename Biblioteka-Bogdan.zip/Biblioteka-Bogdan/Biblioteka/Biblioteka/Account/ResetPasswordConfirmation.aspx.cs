﻿using System.Web.UI;

namespace Biblioteka.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}